package com.jessica.digitalhouse.login.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.jessica.digitalhouse.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }
}
