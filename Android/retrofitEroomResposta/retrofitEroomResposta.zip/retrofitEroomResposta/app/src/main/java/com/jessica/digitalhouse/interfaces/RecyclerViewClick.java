package com.jessica.digitalhouse.interfaces;

import com.jessica.digitalhouse.model.Result;

public interface RecyclerViewClick {

    void clickListenner(Result result);
}
